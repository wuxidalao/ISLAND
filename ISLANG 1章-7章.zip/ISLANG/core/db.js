const Sequelize = require('sequelize')
//连接数据库的相关配置

const {
  dbName,//指定连接数据库名
  host,//数据库的ip地址localhost
  port,//端口，默认3306
  user,//名称root
  password//密码
} = require('../config/config').database

const sequelize = new Sequelize(dbName,user,password,{
  dialect:'mysql',//指定数据库类型  连接数据库需安装相关驱动 如（"mysql2": "^1.6.5",）
  host,
  port,
  logging:true,//每当Sequelize操作数据库时，会把原始命令在命令行中显示出来
  timezone:'+08:00',//如果不设置时间，Sequelize自动生成的时间会和北京时间相差8小时
  define:{
    //create_time updata_time delete_time 一条记录的创建、更新、删除时间
    timestamps:true,
    paranoid:true,
    createdAt:'created_at',
    updatadAt:'updatad_at',
    deletedAt:'deleted_at',
    underscored:true,//驼峰命名转下划线命名
  }
})

sequelize.sync({
  force:false,//自动生成表（一般多为false状态,开发阶段可以为true）
})

module.exports = {
  sequelize
}