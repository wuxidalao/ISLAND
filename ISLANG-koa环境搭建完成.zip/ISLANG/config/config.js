module.exports = {
  //prod生产环境
  //dev开发环境
  environment:'dev'
}